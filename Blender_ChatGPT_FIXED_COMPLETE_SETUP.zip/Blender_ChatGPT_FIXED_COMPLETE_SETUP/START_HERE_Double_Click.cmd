@echo off
setlocal
cd /d "%~dp0"
title Blender + ChatGPT - COMPLETE Setup
powershell.exe -NoProfile -NoLogo -STA -ExecutionPolicy Bypass -File "%~dp0internal\Blender_ChatGPT_Complete_Setup.ps1"
if errorlevel 1 (
  echo.
  echo Setup window could not open. Photograph any error above for troubleshooting.
  pause
)
endlocal
