BLENDER + CHATGPT - COMPLETE WINDOWS SETUP (ONE ZIP, ONE LAUNCHER)
=================================================================

1. Right-click the ZIP > Extract All. Use a normal folder, not the ZIP preview.
2. Double-click START_HERE_Double_Click.cmd. DO NOT open PowerShell or type commands.
3. In the window press INSTALL / REPAIR BLENDER MCP. It downloads and installs
   the community add-on and official Astral uv/uvx. Internet is required.
4. Open Blender. If the MCP add-on is not enabled, go to
   Edit > Preferences > Add-ons > MCP for Blender > tick to enable.
   In the 3D View press N > MCP for Blender > Start MCP Server.
5. In the SAME setup window press CHECK PORT 9876. It should say PASS.
6. Paste YOUR EXISTING BLENDER tunnel ID into the first field.
7. Type YOUR OWN RUNTIME API KEY into the hidden field. Never share it.
8. Press DOWNLOAD TUNNEL-CLIENT IF NEEDED + CONNECT.
   This edition shows the actual tunnel-client stderr/stdout if the process exits.
   The API key field is intentionally wiped after each attempt: a blank field
   after an error does not mean you forgot to enter it.
   The launcher downloads the official OpenAI Windows x64 release if required,
   verifies SHA256SUMS, then starts a SEPARATE Blender tunnel-client process.
9. The ChatGPT website opens. In ChatGPT: Plugins > + > Add custom MCP server
   > Tunnel > select your existing Blender tunnel > review risks and approve.
   You must have permission to create the custom plugin in your workspace.
10. Test a small modeling command through the Blender plugin in ChatGPT.
    Do not claim end-to-end connection until the tool call succeeds.

THIS IS THE ONLY ZIP YOU NEED. It contains all setup scripts and documentation.
You may be asked to approve account permissions or enter credentials privately.
Such approvals cannot be automated by a local Windows ZIP.

Notes:
- Blender must remain open and its addon server running on localhost:9876.
- The tunnel-client process must stay running for ChatGPT to control Blender.
- Existing SOLIDWORKS profiles / tunnel processes are not modified by this installer.
- Node.js/npm is NOT required for this Blender MCP connection.
- Codex is OPTIONAL. The Codex button installs it and registers Blender MCP
  in ~/.codex/config.toml without replacing other MCP sections (backup made).
  Restart Codex after setup. Codex and ChatGPT Work connect separately.
- No OpenAI runtime API key is saved to disk by this launcher. It is passed
  transiently through the child process environment and can be inspected by
  other sufficiently privileged processes while the tunnel runs.
- Blender MCP is community software that can execute code inside Blender.
  This launcher enables BLENDER_MCP_SAFE_MODE=1 for the tunnel subprocess.
  Check upstream permissions and telemetry settings before publishing the ZIP.
- This installer downloads code from the official Astral and OpenAI sites and
  downloads the MCP add-on from the community project via uvx.
- Windows may warn about unsigned scripts. Read the included scripts before use.
- The launcher may not locate an unusual custom installation of Blender or uvx.
- The launcher/process has NOT been verified on the user's Windows computer.

Official references:
https://github.com/ahujasid/mcp-for-blender
https://github.com/openai/tunnel-client/releases/latest
https://developers.openai.com/api/docs/guides/secure-mcp-tunnels
https://docs.astral.sh/uv/getting-started/installation/

TROUBLESHOOTING
--------------
If the install fails, find logs at:
%LOCALAPPDATA%\BlenderChatGPTSetup\setup_*.log

If MCP is missing, install or enable in Blender's Add-ons and restart Blender.
If port 9876 is closed, Start MCP Server inside Blender (N sidebar).
If the tunnel is unavailable in ChatGPT, check the tunnel's association with
that ChatGPT workspace and the runtime key's Tunnels Read + Use permission.
If the process closes immediately, READ THE ERROR DIALOG: this edition captures the process error and redacts the key. If the message is about authentication, confirm that the runtime key (NOT an admin key) has Tunnels Read + Use in the same Platform organization. If it is about missing MCP command, check that uvx is installed. If it is about association, check the intended ChatGPT workspace. An error dialog is not proof of the root cause until you read its text.
Never share screenshots containing an API key.
