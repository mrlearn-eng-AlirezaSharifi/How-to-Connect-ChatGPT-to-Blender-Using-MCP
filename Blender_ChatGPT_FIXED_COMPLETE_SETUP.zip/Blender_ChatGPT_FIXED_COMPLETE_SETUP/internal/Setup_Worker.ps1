param(
    [ValidateSet('All','UV','Addon','Codex','Register','Node','FullCodex')]
    [string]$Action = 'All',
    [string]$LogFile,
    [switch]$IncludeNode
)

$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}
if (-not $LogFile) { $LogFile = Join-Path $env:TEMP 'blender_mcp_setup.log' }

function Log([string]$msg) {
    $stamp = Get-Date -Format 'HH:mm:ss'
    Add-Content -LiteralPath $LogFile -Value "[$stamp] $msg" -Encoding UTF8
}
function Refresh-Path {
    $systemPath = [Environment]::GetEnvironmentVariable('PATH', 'Machine')
    $userPath = [Environment]::GetEnvironmentVariable('PATH', 'User')
    $extra = @(
        (Join-Path $env:USERPROFILE '.local\bin'),
        (Join-Path $env:APPDATA 'npm'),
        (Join-Path $env:USERPROFILE '.codex\bin')
    )
    $env:PATH = (($systemPath, $userPath) + $extra) -join ';'
}
function Find-Exe([string]$name) {
    Refresh-Path
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { return $cmd.Source }
    $folders = @(
       (Join-Path $env:USERPROFILE '.local\bin'),
       (Join-Path $env:USERPROFILE '.codex\bin'),
       (Join-Path $env:LOCALAPPDATA 'Programs\uv\bin'),
       (Join-Path $env:APPDATA 'npm')
    )
    foreach ($folder in $folders) {
        $p = Join-Path $folder $name
        if (Test-Path -LiteralPath $p) { return $p }
    }
    return $null
}
function Download-OfficialScript([string]$url, [string]$filename) {
    $tempFile = Join-Path $env:TEMP $filename
    Log "Downloading the official installer from $url"
    Invoke-WebRequest -Uri $url -OutFile $tempFile -UseBasicParsing -TimeoutSec 90
    if (-not (Test-Path $tempFile) -or ((Get-Item $tempFile).Length -lt 100)) {
        throw "Official installer download was empty."
    }
    return $tempFile
}
function Run-OfficialScript([string]$url,[string]$filename) {
    $file = Download-OfficialScript $url $filename
    Log 'Running downloaded official installation script...'
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
       & $file 2>&1 | ForEach-Object {
           if ($null -ne $_) {
               $line = if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { [string]$_ }
               if (-not [string]::IsNullOrWhiteSpace($line)) { Log ('  ' + $line.Trim()) }
           }
       }
    } finally {
       $ErrorActionPreference = $oldPreference
       Remove-Item -LiteralPath $file -Force -ErrorAction SilentlyContinue
    }
    Refresh-Path
}
function Ensure-Uv {
    $uvx = Find-Exe 'uvx.exe'
    if ($uvx) {
        Log "PASS: uvx available: $uvx"
        return $uvx
    }
    Log 'Installing uv and uvx from Astral (official installer), without winget.'
    Run-OfficialScript 'https://astral.sh/uv/install.ps1' 'blendgpt_official_uv_install.ps1'
    $uvx = Find-Exe 'uvx.exe'
    if (-not $uvx) { throw 'uvx still missing. Restart Windows and run this installer again, or consult the log.' }
    Log "PASS: uvx installed: $uvx"
    return $uvx
}
function Install-Addon {
    $uvx = Ensure-Uv
    Log 'Installing or updating the community MCP for Blender add-on...'
    Log 'INFO: UV may print normal download progress as stderr; checking exit code after completion.'
    Log 'Command executed for you: uvx mcp-for-blender install-addon'
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $uvx 'mcp-for-blender' 'install-addon' 2>&1 | ForEach-Object {
            if ($null -eq $_) { return }
            # Windows PowerShell 5.1 wraps uv's normal download progress (stderr)
            # as NativeCommandError. This is not necessarily a failed installation.
            $line = if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { [string]$_ }
            if (-not [string]::IsNullOrWhiteSpace($line)) { Log ('  ' + $line.Trim()) }
        }
        $rc = $LASTEXITCODE
    } finally { $ErrorActionPreference = $oldPreference }
    if ($rc -ne 0) { throw "Blender add-on installation failed (exit code $rc). Read log for details." }
    Log 'PASS: MCP add-on installation command finished.'
    Log 'In Blender, enable MCP for Blender in Preferences > Add-ons if needed.'
    Log 'Then 3D View > N > MCP for Blender > Start MCP Server (if not already started).'
}
function Install-Codex {
    $codex = Find-Exe 'codex.exe'
    if (-not $codex) { $codex = Find-Exe 'codex.cmd' }
    if ($codex) { Log "PASS: Codex already available: $codex"; return }
    Log 'Installing Codex CLI with the official OpenAI Windows installer...'
    Run-OfficialScript 'https://chatgpt.com/codex/install.ps1' 'blendgpt_official_codex_install.ps1'
    $codex = Find-Exe 'codex.exe'
    if (-not $codex) { $codex = Find-Exe 'codex.cmd' }
    if ($codex) {
        Log "PASS: Codex available: $codex"
    } else {
        Log 'WARNING: Could not locate Codex CLI on PATH yet. Registration will still work for the Codex desktop app once installed.'
    }
}
function Register-Codex {
    $uvx = Ensure-Uv
    # Update only the dedicated Blender section, never other MCP entries.
    $homeDir = $env:USERPROFILE
    if ($env:CODEX_HOME) { $homeDir = $env:CODEX_HOME } else { $homeDir = Join-Path $homeDir '.codex' }
    if (-not (Test-Path -LiteralPath $homeDir)) {
        New-Item -ItemType Directory -Path $homeDir -Force | Out-Null
    }
    $config = Join-Path $homeDir 'config.toml'
    $content = ''
    if (Test-Path -LiteralPath $config) {
        $content = [System.IO.File]::ReadAllText($config)
    }
    $pathQuoted = '"' + $uvx.Replace('\','\\').Replace('"','\"') + '"'
    $blenderBlock = "[mcp_servers.blender]`r`ncommand = $pathQuoted`r`nargs = [`"mcp-for-blender`"]`r`n"
    $pattern = '(?ms)^\[mcp_servers\.blender\][ \t]*\r?\n.*?(?=^\[|\z)'
    $matches = [regex]::Matches($content, $pattern)
    if ($matches.Count -gt 1) { throw 'Multiple blender sections found in Codex config. Please resolve them manually before setup.' }
    if ($matches.Count -eq 1) {
        $previous = $matches[0].Value
        if ($previous.Contains($pathQuoted) -and $previous.Contains('mcp-for-blender')) {
            Log 'PASS: Codex is already configured for this Blender MCP server.'
            return
        }
    }
    if (Test-Path -LiteralPath $config) {
        $backup = "$config.blender-backup-$(Get-Date -Format 'yyyyMMdd-HHmmss')"
        Copy-Item -LiteralPath $config -Destination $backup -ErrorAction Stop
        Log "Backup created: $backup"
    }
    if ($matches.Count -eq 1) {
        $content = [regex]::Replace($content, $pattern, ($blenderBlock + "`r`n"))
        Log 'Updated the existing Blender MCP section only.'
    } else {
        if ($content.Length -gt 0 -and -not $content.EndsWith("`n")) { $content += "`r`n" }
        $content += "`r`n" + $blenderBlock
        Log 'Added a new Blender MCP section. Other servers remain untouched.'
    }
    [System.IO.File]::WriteAllText($config, $content, (New-Object System.Text.UTF8Encoding($false)))
    Log "PASS: Codex MCP configuration saved: $config"
    Log 'Restart Codex after configuration changes.'
}
function Install-Node {
    $npm = Find-Exe 'npm.cmd'
    if ($npm) { Log "PASS: Node/npm already available: $npm"; return }
    $winget = Find-Exe 'winget.exe'
    if (-not $winget) {
        Log 'NOTE: winget unavailable. Install optional Node.js from https://nodejs.org/en/download'
        return
    }
    Log 'Installing optional Node.js LTS (for npm) via Microsoft winget...'
    $oldPreference = $ErrorActionPreference
    $ErrorActionPreference = 'Continue'
    try {
        & $winget 'install' '--id' 'OpenJS.NodeJS.LTS' '-e' '--source' 'winget' '--accept-package-agreements' '--accept-source-agreements' '--silent' 2>&1 | ForEach-Object {
            if ($null -ne $_) {
                $line = if ($_ -is [System.Management.Automation.ErrorRecord]) { $_.Exception.Message } else { [string]$_ }
                if (-not [string]::IsNullOrWhiteSpace($line)) { Log ('  ' + $line.Trim()) }
            }
        }
        $rc = $LASTEXITCODE
    } finally { $ErrorActionPreference = $oldPreference }
    if ($rc -ne 0) { Log "WARNING: Optional Node installation returned code $rc. You can install it from nodejs.org." }
    Refresh-Path
    if (Find-Exe 'npm.cmd') { Log 'PASS: Node/npm available.' } else { Log 'Node may need a Windows restart before npm becomes available.' }
}

try {
    Log '============================================================'
    Log "Starting: $Action  |  Windows 10/11  |  no manual terminal input"
    Log 'Online installers use official Astral/OpenAI sources and community Blender MCP.'
    switch ($Action) {
        'UV'       { $null = Ensure-Uv }
        'Addon'    { Install-Addon }
        'Codex'    { Install-Codex }
        'FullCodex' { Install-Codex; Register-Codex }
        'Register' { Register-Codex }
        'Node'     { Install-Node }
        'All' {
            $null = Ensure-Uv
            if ($IncludeNode) { Install-Node }
            Install-Addon
            Log 'Optional Codex installation is available using the separate button in the same window.'
        }
    }
    Log 'SUCCESS: Selected installation tasks finished.'
    exit 0
} catch {
    Log ('ERROR: ' + $_.Exception.Message)
    Log ('At: ' + $_.ScriptStackTrace)
    Log 'Installation stopped. You can retry after correcting the issue.'
    exit 1
}
