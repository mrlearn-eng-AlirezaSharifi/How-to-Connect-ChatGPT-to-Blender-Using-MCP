# BLENDER + CHATGPT - SINGLE-LAUNCHER WINDOWS SETUP
# Starts only when the user double-clicks START_HERE_Double_Click.cmd.
# Community integration: https://github.com/ahujasid/mcp-for-blender
# Official tunnel client: https://github.com/openai/tunnel-client
# NEVER persists user runtime API key; never writes/edits SOLIDWORKS files.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()
$ErrorActionPreference = 'Stop'
try { [Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12 } catch {}

function Find-Program([string]$name) {
    $candidates = New-Object 'System.Collections.Generic.List[string]'
    $cmd = Get-Command $name -ErrorAction SilentlyContinue
    if ($cmd -and $cmd.Source) { $candidates.Add([string]$cmd.Source) }
    foreach ($base in @(
        (Join-Path $env:USERPROFILE '.local\bin'),
        (Join-Path $env:LOCALAPPDATA 'Programs\uv\bin'),
        (Join-Path $env:APPDATA 'npm'),
        (Join-Path $env:USERPROFILE '.codex\bin'),
        (Join-Path $env:LOCALAPPDATA 'BlenderChatGPTSetup\tunnel-client')
    )) {
        $candidates.Add((Join-Path $base $name))
    }
    foreach ($candidate in $candidates) {
        if ($candidate -and (Test-Path -LiteralPath $candidate -PathType Leaf)) { return (Resolve-Path -LiteralPath $candidate).ProviderPath }
    }
    if ($name -eq 'tunnel-client.exe') {
        $folder = Join-Path $env:LOCALAPPDATA 'BlenderChatGPTSetup\tunnel-client'
        if (Test-Path -LiteralPath $folder) {
            $found = @(Get-ChildItem -LiteralPath $folder -Filter 'tunnel-client.exe' -File -Recurse -ErrorAction SilentlyContinue | Select-Object -First 1)
            if ($found.Count -gt 0) { return $found[0].FullName }
        }
    }
    return $null
}
function Find-Blender {
    $base = Join-Path $env:ProgramFiles 'Blender Foundation'
    if (Test-Path -LiteralPath $base) {
        foreach ($folder in @(Get-ChildItem -LiteralPath $base -Directory -ErrorAction SilentlyContinue | Sort-Object Name -Descending)) {
            $exe = Join-Path $folder.FullName 'blender.exe'
            if (Test-Path -LiteralPath $exe -PathType Leaf) { return $exe }
        }
    }
    return Find-Program 'blender.exe'
}
function Is-Blender-Port-Open {
    $tcp = New-Object System.Net.Sockets.TcpClient
    try {
        $async = $tcp.BeginConnect('127.0.0.1', 9876, $null, $null)
        if (-not $async.AsyncWaitHandle.WaitOne(1400)) { return $false }
        $tcp.EndConnect($async)
        return $tcp.Connected
    } catch { return $false } finally { $tcp.Close() }
}
function Display-Message([string]$text, [string]$type='Information') {
    $icon = if ($type -eq 'Error') { 'Error' } elseif ($type -eq 'Warning') { 'Warning' } else { 'Information' }
    [System.Windows.Forms.MessageBox]::Show($text, 'Blender + ChatGPT Complete Setup', 'OK', $icon) | Out-Null
}
function Download-Tunnel-Client {
    # Uses OpenAI's latest GitHub release and checks the archive against the release SHA256SUMS file.
    $base = Join-Path $env:LOCALAPPDATA 'BlenderChatGPTSetup\tunnel-client'
    if (-not (Test-Path -LiteralPath $base)) { New-Item -ItemType Directory -Force -Path $base | Out-Null }
    $release = Invoke-RestMethod -Uri 'https://api.github.com/repos/openai/tunnel-client/releases/latest' -Headers @{'User-Agent'='BlenderMCPCompleteSetup'} -TimeoutSec 45
    $tag = [string]$release.tag_name
    if ($tag -notmatch '^v\d+\.\d+\.\d+$') { throw 'Unexpected official release version. Use the Browse button to select your tunnel-client.exe.' }
    $assetName = 'tunnel-client-' + $tag + '-windows-amd64.zip'
    $asset = @($release.assets | Where-Object { $_.name -eq $assetName } | Select-Object -First 1)
    $checksum = @($release.assets | Where-Object { $_.name -eq 'SHA256SUMS.txt' } | Select-Object -First 1)
    if ($asset.Count -ne 1 -or $checksum.Count -ne 1) { throw "Official Windows x64 archive or SHA256SUMS.txt not found for $tag." }
    if ($asset[0].browser_download_url -notlike 'https://github.com/openai/tunnel-client/releases/download/*') { throw 'Unexpected download URL.' }
    if ($checksum[0].browser_download_url -notlike 'https://github.com/openai/tunnel-client/releases/download/*') { throw 'Unexpected checksum URL.' }
    $zip = Join-Path $base $assetName
    $sums = Join-Path $base ('SHA256SUMS_' + $tag + '.txt')
    Invoke-WebRequest -Uri $asset[0].browser_download_url -OutFile $zip -UseBasicParsing -TimeoutSec 240
    Invoke-WebRequest -Uri $checksum[0].browser_download_url -OutFile $sums -UseBasicParsing -TimeoutSec 90
    $matches = @(Get-Content -LiteralPath $sums | Where-Object { $_ -match ('\s\*?' + [regex]::Escape($assetName) + '$') })
    if ($matches.Count -ne 1) { throw 'Could not find an unambiguous SHA256SUMS entry for the Windows archive.' }
    $expected = ($matches[0].Trim() -split '\s+')[0].ToLowerInvariant()
    if ($expected -notmatch '^[0-9a-f]{64}$') { throw 'Invalid checksum in official file.' }
    $actual = (Get-FileHash -LiteralPath $zip -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($expected -ne $actual) { throw 'Security check FAILED: downloaded archive checksum did not match.' }
    $folder = Join-Path $base ('release_' + $tag)
    if (-not (Test-Path -LiteralPath $folder)) { New-Item -ItemType Directory -Force -Path $folder | Out-Null }
    Expand-Archive -LiteralPath $zip -DestinationPath $folder -Force
    $exe = @(Get-ChildItem -LiteralPath $folder -Filter 'tunnel-client.exe' -File -Recurse | Select-Object -First 1)
    if ($exe.Count -ne 1) { throw 'Downloaded OpenAI release did not contain tunnel-client.exe.' }
    return $exe[0].FullName
}

$form = New-Object System.Windows.Forms.Form
$form.Text='BLENDER + CHATGPT | Complete setup (one ZIP, diagnostics)'
$form.StartPosition = 'CenterScreen'
$form.Size = New-Object System.Drawing.Size(785,875)
$form.MinimumSize = $form.Size
$form.MaximumSize = $form.Size
$form.Font = New-Object System.Drawing.Font('Segoe UI',10)
$form.BackColor = [System.Drawing.Color]::FromArgb(246,248,252)
$blue = [System.Drawing.Color]::FromArgb(26,102,192)
$ink  = [System.Drawing.Color]::FromArgb(31,45,61)
$muted= [System.Drawing.Color]::FromArgb(83,101,118)

function Ui-Label([string]$text,[int]$x,[int]$y,[int]$w,[int]$h,[bool]$bold=$false) {
    $label=New-Object System.Windows.Forms.Label
    $label.Location=New-Object System.Drawing.Point($x,$y)
    $label.Size=New-Object System.Drawing.Size($w,$h)
    $label.Text=$text
    $label.ForeColor=if ($bold) { $ink } else { $muted }
    if ($bold) { $label.Font=New-Object System.Drawing.Font('Segoe UI',11.5,[System.Drawing.FontStyle]::Bold) }
    $form.Controls.Add($label)
    return $label
}
function Ui-Button([string]$text,[int]$x,[int]$y,[int]$w,[int]$h,[bool]$primary=$false) {
    $button=New-Object System.Windows.Forms.Button
    $button.Text=$text
    $button.Location=New-Object System.Drawing.Point($x,$y)
    $button.Size=New-Object System.Drawing.Size($w,$h)
    $button.FlatStyle=[System.Windows.Forms.FlatStyle]::Flat
    if ($primary) { $button.BackColor=$blue; $button.ForeColor=[Drawing.Color]::White }
    else { $button.BackColor=[Drawing.Color]::White; $button.ForeColor=$ink }
    $form.Controls.Add($button)
    return $button
}
function Ui-Line([int]$y) {
    $p=New-Object Windows.Forms.Panel
    $p.Location=New-Object Drawing.Point(22,$y)
    $p.Size=New-Object Drawing.Size(723,1)
    $p.BackColor=[Drawing.Color]::FromArgb(215,224,235)
    $form.Controls.Add($p)
}

$h=Ui-Label 'BLENDER + CHATGPT COMPLETE SETUP' 22 15 734 40 $true
$h.Font=New-Object Drawing.Font('Segoe UI',17,[Drawing.FontStyle]::Bold)
$null=Ui-Label 'One ZIP. One START HERE file. No PowerShell commands to type.' 24 58 720 25

Ui-Line 94
$null=Ui-Label '1  INSTALL BLENDER MCP' 23 109 700 29 $true
$null=Ui-Label 'Installs uv/uvx and the Blender MCP add-on (skips tools already present).' 24 140 712 23
$installBtn=Ui-Button 'INSTALL / REPAIR BLENDER MCP' 24 171 346 44 $true
$codexBtn=Ui-Button 'OPTIONAL: SET UP CODEX' 386 171 346 44

Ui-Line 230
$null=Ui-Label '2  START BLENDER SERVER' 23 245 704 29 $true
$null=Ui-Label 'Inside Blender: 3D Viewport > N > MCP for Blender > Start MCP Server.' 24 275 720 25
$openBlenderBtn=Ui-Button 'OPEN BLENDER' 24 305 345 43
$checkPortBtn=Ui-Button 'CHECK PORT 9876' 386 305 346 43

Ui-Line 362
$null=Ui-Label '3  CONNECT CHATGPT WORK (SECURE TUNNEL)' 23 375 710 28 $true
$null=Ui-Label 'Use your existing Blender tunnel ID + runtime key. Keep them private.' 24 406 710 25
$idLabel=Ui-Label 'Blender tunnel ID:' 24 441 250 22
$idBox=New-Object Windows.Forms.TextBox
$idBox.Location=New-Object Drawing.Point(24,468); $idBox.Size=New-Object Drawing.Size(708,31)
$form.Controls.Add($idBox)
$keyLabel=Ui-Label 'OpenAI runtime API key (hidden, never saved by this installer):' 24 511 690 23
$keyBox=New-Object Windows.Forms.TextBox
$keyBox.Location=New-Object Drawing.Point(24,540); $keyBox.Size=New-Object Drawing.Size(708,31)
$keyBox.UseSystemPasswordChar=$true
$form.Controls.Add($keyBox)
$connectBtn=Ui-Button 'DOWNLOAD TUNNEL-CLIENT IF NEEDED + CONNECT' 24 586 708 52 $true
$null=Ui-Label 'Only one Blender tunnel process per tunnel ID. Your SOLIDWORKS profile is never edited.' 24 648 716 31

Ui-Line 689
$openPlugins=Ui-Button 'OPEN CHATGPT / PLUGINS' 24 705 344 40
$tunnelSettings=Ui-Button 'OPEN OPENAI TUNNEL SETTINGS' 386 705 346 40
$status=Ui-Label 'Ready. Start with Step 1, or use Step 3 if Blender MCP is already installed.' 24 752 719 32
$status.ForeColor=$blue
$more=Ui-Label 'Errors now show the actual tunnel-client message (key redacted). ChatGPT plugin approval is still needed.' 24 784 722 28
$more.Font=New-Object Drawing.Font('Segoe UI',9)

$script:worker=$null
$script:jobLog=$null
$script:oldLength=0
$script:tunnelProc=$null
$base=Join-Path $env:LOCALAPPDATA 'BlenderChatGPTSetup'
if (-not (Test-Path -LiteralPath $base)) { New-Item -ItemType Directory -Path $base -Force | Out-Null }
function Start-Install([string]$action) {
    if ($script:worker -and -not $script:worker.HasExited) { Display-Message 'An installation is already running.' 'Warning'; return }
    $script:jobLog=Join-Path $base ('setup_' + $action + '_' + (Get-Date -Format 'yyyyMMdd_HHmmss') + '.log')
    [IO.File]::WriteAllText($script:jobLog,'',[Text.UTF8Encoding]::new($false))
    $workerFile=Join-Path $PSScriptRoot 'Setup_Worker.ps1'
    $arguments='-NoProfile -NoLogo -ExecutionPolicy Bypass -File "' + $workerFile + '" -Action ' + $action + ' -LogFile "' + $script:jobLog + '"'
    try {
        $script:worker=Start-Process -FilePath 'powershell.exe' -ArgumentList $arguments -WindowStyle Hidden -PassThru
        $status.Text='Installing components. You can leave this window open to see the result.'
        $installBtn.Enabled=$false
        $codexBtn.Enabled=$false
    } catch { Display-Message $_.Exception.Message 'Error' }
}
$installBtn.Add_Click({ Start-Install 'All' })
$codexBtn.Add_Click({
    # CODEx is optional; all files are in this ZIP.
    if (-not (Find-Program 'uvx.exe')) { Display-Message 'Install Blender MCP using Step 1 first.' 'Warning'; return }
    Start-Install 'FullCodex'
})
$openBlenderBtn.Add_Click({
    $path=Find-Blender
    if ($path) { Start-Process -FilePath $path; $status.Text='Blender opened. In the 3D viewport press N > MCP for Blender.' }
    else { Start-Process 'https://www.blender.org/download/'; $status.Text='Blender was not found. Official Blender download page opened.' }
})
$checkPortBtn.Add_Click({
    if (Is-Blender-Port-Open) { $status.Text='PASS: Blender MCP port 9876 is open.'; Display-Message 'Blender is listening locally on port 9876. You can now connect the tunnel.' }
    else { $status.Text='Blender MCP port 9876 is closed.'; Display-Message 'Open Blender. In 3D View press N > MCP for Blender > Start MCP Server. Then click CHECK PORT 9876.' 'Warning' }
})
$tunnelSettings.Add_Click({ Start-Process 'https://platform.openai.com/settings/organization/tunnels' })
$openPlugins.Add_Click({ Start-Process 'https://chatgpt.com/' })
$connectBtn.Add_Click({
    $id=$idBox.Text.Trim()
    $key=$keyBox.Text.Trim()
    if ($id -notmatch '^tunnel_[a-zA-Z0-9_]+$') { Display-Message 'Paste your Blender tunnel ID (starts with tunnel_) into the first field.' 'Warning'; return }
    if ($key.Length -lt 15) { Display-Message 'Paste your private OpenAI runtime API key into the second field. It is cleared after every connection attempt for safety.' 'Warning'; return }
    if (-not (Is-Blender-Port-Open)) { Display-Message 'Blender MCP port 9876 is not open. In Blender: press N > MCP for Blender > Start MCP Server.' 'Warning'; return }
    $uvx=Find-Program 'uvx.exe'
    if (-not $uvx) { Display-Message 'uvx is not installed. Use INSTALL / REPAIR BLENDER MCP first.' 'Warning'; return }
    if ($script:tunnelProc -and -not $script:tunnelProc.HasExited) { Display-Message 'Your Blender tunnel is already running from this setup. Do not start a second copy.' 'Warning'; return }
    $connectBtn.Enabled=$false
    $form.Cursor=[Windows.Forms.Cursors]::WaitCursor
    try {
        $client=Find-Program 'tunnel-client.exe'
        if (-not $client) {
            $status.Text='Downloading official tunnel-client and verifying SHA256...'
            [Windows.Forms.Application]::DoEvents()
            $client=Download-Tunnel-Client
        }
        $status.Text='Starting Blender tunnel-client and capturing diagnostics...'
        [Windows.Forms.Application]::DoEvents()

        # The process receives the runtime key ONLY in its environment. Do not put
        # it in CLI arguments, an on-disk YAML file, or the installer ZIP.
        $psi=New-Object System.Diagnostics.ProcessStartInfo
        $psi.FileName=$client
        $psi.WorkingDirectory=$base
        # Use documented flags, rather than depending on an inherited MCP_COMMAND.
        # uvx is found via the per-process PATH modification below.
        $psi.Arguments=('run --control-plane.tunnel-id={0} --mcp.command="uvx mcp-for-blender" --log.level=info' -f $id)
        $psi.UseShellExecute=$false
        $psi.CreateNoWindow=$true
        $psi.RedirectStandardOutput=$true
        $psi.RedirectStandardError=$true
        $psi.EnvironmentVariables['CONTROL_PLANE_API_KEY']=$key
        $psi.EnvironmentVariables['CONTROL_PLANE_TUNNEL_ID']=$id
        $psi.EnvironmentVariables['BLENDER_MCP_SAFE_MODE']='1'
        $psi.EnvironmentVariables['BLENDER_HOST']='127.0.0.1'
        $psi.EnvironmentVariables['BLENDER_PORT']='9876'
        $psi.EnvironmentVariables['PATH']=(Split-Path -Path $uvx -Parent) + ';' + $psi.EnvironmentVariables['PATH']
        foreach ($name in @('MCP_SERVER_URL','MCP_COMMAND','TUNNEL_CLIENT_CONFIG','TUNNEL_CLIENT_PROFILE')) {
            if ($psi.EnvironmentVariables.ContainsKey($name)) { $psi.EnvironmentVariables.Remove($name) }
        }
        $script:tunnelProc=New-Object System.Diagnostics.Process
        $script:tunnelProc.StartInfo=$psi
        if (-not $script:tunnelProc.Start()) { throw 'Windows could not start tunnel-client.exe.' }
        # Drain both streams asynchronously so the tunnel cannot block on a full
        # console pipe. The strings are used ONLY if the process exits.
        $script:stdoutTask=$script:tunnelProc.StandardOutput.ReadToEndAsync()
        $script:stderrTask=$script:tunnelProc.StandardError.ReadToEndAsync()
        $keyBox.Clear()
        Start-Sleep -Milliseconds 2200
        if ($script:tunnelProc.HasExited) {
            $code=$script:tunnelProc.ExitCode
            $raw=''
            try { if ($script:stderrTask.Wait(1500)) { $raw += $script:stderrTask.Result } } catch {}
            try { if ($script:stdoutTask.Wait(1500)) { $raw += "`r`n" + $script:stdoutTask.Result } } catch {}
            # Do not display or retain the entered key even if a dependency echoed it.
            $raw=$raw.Replace($key,'[REDACTED]')
            $raw=[regex]::Replace($raw,'sk-[A-Za-z0-9_\-]{8,}','[REDACTED]')
            $raw=[regex]::Replace($raw,'(?i)(authorization\s*[:=]\s*bearer\s+)\S+','$1[REDACTED]')
            if ([string]::IsNullOrWhiteSpace($raw)) { $raw='No console error text was returned by tunnel-client.' }
            $raw=$raw.Trim()
            if ($raw.Length -gt 2600) { $raw=$raw.Substring($raw.Length-2600) }
            $status.Text=('Tunnel-client exited (code {0}). Read the detailed error popup.' -f $code)
            Display-Message ("Connection failed. tunnel-client exit code: $code`r`n`r`n$raw`r`n`r`nThe key has been cleared from the input. Copy it again for a retry. Do not send anyone your API key.") 'Error'
        } else {
            $status.Text='Tunnel process is running. Finish approval in ChatGPT and test a Blender tool.'
            Start-Process 'https://chatgpt.com/'
            Display-Message 'The Blender tunnel process is running. This does not yet prove tool access. Open ChatGPT > Plugins > Add custom MCP server > Tunnel, select the Blender tunnel, approve it, and test a harmless Blender tool. Keep Blender and this window open.'
        }
    } catch {
        $status.Text='Tunnel download or start failed. Read the error popup.'
        $reason=$_.Exception.Message
        if ($key) { $reason=$reason.Replace($key,'[REDACTED]') }
        Display-Message ('Could not start the Blender tunnel: ' + $reason) 'Error'
        $keyBox.Clear()
    } finally {
        $key=$null
        $form.Cursor=[Windows.Forms.Cursors]::Default
        $connectBtn.Enabled=$true
    }
})
$timer=New-Object Windows.Forms.Timer
$timer.Interval=700
$timer.Add_Tick({
    if (-not $script:worker) { return }
    if ($script:jobLog -and (Test-Path -LiteralPath $script:jobLog)) {
        try {
            $lines=@(Get-Content -LiteralPath $script:jobLog -Tail 4 -ErrorAction SilentlyContinue)
            if ($lines.Count -gt 0) {
                $last=[string]$lines[-1]
                if ($last.Length -gt 132) { $last=$last.Substring(0,132) }
                $status.Text=$last
            }
        } catch {}
    }
    if ($script:worker.HasExited) {
        $rc=$script:worker.ExitCode
        $script:worker.Dispose()
        $script:worker=$null
        $installBtn.Enabled=$true
        $codexBtn.Enabled=$true
        if ($rc -eq 0) { $status.Text='PASS: Installation completed. Next: Start Blender MCP server (Step 2).'; Display-Message 'Installation succeeded. Open Blender and check that the MCP server is running on port 9876.' }
        else { $status.Text='Installation failed. See setup log in AppData > BlenderChatGPTSetup.'; Display-Message ('Installation failed. Setup log is saved in: ' + $base + '. You can retry the installation.') 'Warning' }
    }
})
$timer.Start()
$form.Add_FormClosed({ $timer.Stop(); $keyBox.Clear() })
[void]$form.ShowDialog()
